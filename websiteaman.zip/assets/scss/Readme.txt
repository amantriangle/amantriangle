The .scss (Sass) files are only available in the pro version.
You can buy it from: https://Fuais.com/knight-simple-one-page-bootstrap-template/